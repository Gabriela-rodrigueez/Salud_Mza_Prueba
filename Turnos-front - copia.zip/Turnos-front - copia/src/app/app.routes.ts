import { Routes } from '@angular/router';
import { InicioPublicoComponent } from './features/inicio-publico/inicio-publico';

// Tus componentes de login
import { LoginPaciente } from './features/auth/login-paciente/login-paciente';
import { LoginMedico } from './features/auth/login-medico/login-medico';
import { LoginAdmin } from './features/auth/login-admin/login-admin';

export const routes: Routes = [
  // Tu pantalla principal (Landing Page)
  { path: '', component: InicioPublicoComponent },
  
  // Tus rutas de Login
  { path: 'auth/login-paciente', component: LoginPaciente },
  { path: 'auth/login-medico', component: LoginMedico },
  { path: 'auth/login-admin', component: LoginAdmin },
];