import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-centros-cercanos',
  styleUrl: './centros-cercanos.css',
  templateUrl: './centros-cercanos.html',
})
export class CentrosCercanos {}
