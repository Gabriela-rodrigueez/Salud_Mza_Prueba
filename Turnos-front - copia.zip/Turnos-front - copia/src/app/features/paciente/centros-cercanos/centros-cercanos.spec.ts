import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CentrosCercanos } from './centros-cercanos';

describe('CentrosCercanos', () => {
  let component: CentrosCercanos;
  let fixture: ComponentFixture<CentrosCercanos>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CentrosCercanos],
    }).compileComponents();

    fixture = TestBed.createComponent(CentrosCercanos);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
