import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-modo-tutor',
  styleUrl: './modo-tutor.css',
  templateUrl: './modo-tutor.html',
})
export class ModoTutor {}
