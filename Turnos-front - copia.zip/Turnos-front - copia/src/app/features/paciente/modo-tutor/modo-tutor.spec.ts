import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModoTutor } from './modo-tutor';

describe('ModoTutor', () => {
  let component: ModoTutor;
  let fixture: ComponentFixture<ModoTutor>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModoTutor],
    }).compileComponents();

    fixture = TestBed.createComponent(ModoTutor);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
