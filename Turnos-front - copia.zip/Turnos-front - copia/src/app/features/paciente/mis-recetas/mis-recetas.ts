import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-mis-recetas',
  styleUrl: './mis-recetas.css',
  templateUrl: './mis-recetas.html',
})
export class MisRecetas {}
