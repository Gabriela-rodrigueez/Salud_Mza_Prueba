import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-grupo-familiar',
  styleUrl: './grupo-familiar.css',
  templateUrl: './grupo-familiar.html',
})
export class GrupoFamiliar {}
