import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-mis-turnos',
  styleUrl: './mis-turnos.css',
  templateUrl: './mis-turnos.html',
})
export class MisTurnos {}
