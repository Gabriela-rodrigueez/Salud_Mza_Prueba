import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-resultados-estudios',
  styleUrl: './resultados-estudios.css',
  templateUrl: './resultados-estudios.html',
})
export class ResultadosEstudios {}
