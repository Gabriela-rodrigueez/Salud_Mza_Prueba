import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ResultadosEstudios } from './resultados-estudios';

describe('ResultadosEstudios', () => {
  let component: ResultadosEstudios;
  let fixture: ComponentFixture<ResultadosEstudios>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResultadosEstudios],
    }).compileComponents();

    fixture = TestBed.createComponent(ResultadosEstudios);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
