import { Component } from '@angular/core';
import { RouterModule } from '@angular/router'; 

@Component({
  selector: 'app-inicio-publico',
  standalone: true,
  imports: [RouterModule], 
  templateUrl: './inicio-publico.html',
  styleUrls: ['./inicio-publico.css']
})
export class InicioPublicoComponent {}
