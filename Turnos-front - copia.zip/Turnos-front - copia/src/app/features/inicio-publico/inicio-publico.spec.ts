import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InicioPublico } from './inicio-publico';

describe('InicioPublico', () => {
  let component: InicioPublico;
  let fixture: ComponentFixture<InicioPublico>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InicioPublico],
    }).compileComponents();

    fixture = TestBed.createComponent(InicioPublico);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
