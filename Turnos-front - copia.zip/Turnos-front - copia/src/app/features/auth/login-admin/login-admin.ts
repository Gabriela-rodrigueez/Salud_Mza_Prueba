import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-login-admin',
  styleUrl: './login-admin.css',
  templateUrl: './login-admin.html',
})
export class LoginAdmin {}
