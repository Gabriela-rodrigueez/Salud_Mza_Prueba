import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-login-medico',
  styleUrl: './login-medico.css',
  templateUrl: './login-medico.html',
})
export class LoginMedico {}
