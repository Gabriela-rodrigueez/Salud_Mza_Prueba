import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginMedico } from './login-medico';

describe('LoginMedico', () => {
  let component: LoginMedico;
  let fixture: ComponentFixture<LoginMedico>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoginMedico],
    }).compileComponents();

    fixture = TestBed.createComponent(LoginMedico);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
