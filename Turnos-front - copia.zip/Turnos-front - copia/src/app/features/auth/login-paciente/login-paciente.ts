import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-login-paciente',
  styleUrl: './login-paciente.css',
  templateUrl: './login-paciente.html',
})
export class LoginPaciente {}
