import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-rendimiento',
  styleUrl: './rendimiento.css',
  templateUrl: './rendimiento.html',
})
export class Rendimiento {}
