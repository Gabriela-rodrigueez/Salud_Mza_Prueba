import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-registro-validacion',
  styleUrl: './registro-validacion.css',
  templateUrl: './registro-validacion.html',
})
export class RegistroValidacion {}
