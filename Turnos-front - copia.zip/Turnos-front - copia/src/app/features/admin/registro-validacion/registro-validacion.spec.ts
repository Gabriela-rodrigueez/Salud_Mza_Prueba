import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RegistroValidacion } from './registro-validacion';

describe('RegistroValidacion', () => {
  let component: RegistroValidacion;
  let fixture: ComponentFixture<RegistroValidacion>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegistroValidacion],
    }).compileComponents();

    fixture = TestBed.createComponent(RegistroValidacion);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
