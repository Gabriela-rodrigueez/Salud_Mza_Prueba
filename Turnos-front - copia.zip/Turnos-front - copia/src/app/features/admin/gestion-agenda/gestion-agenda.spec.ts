import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GestionAgenda } from './gestion-agenda';

describe('GestionAgenda', () => {
  let component: GestionAgenda;
  let fixture: ComponentFixture<GestionAgenda>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionAgenda],
    }).compileComponents();

    fixture = TestBed.createComponent(GestionAgenda);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
