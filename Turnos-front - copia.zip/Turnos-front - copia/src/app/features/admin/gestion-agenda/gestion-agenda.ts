import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-gestion-agenda',
  styleUrl: './gestion-agenda.css',
  templateUrl: './gestion-agenda.html',
})
export class GestionAgenda {}
