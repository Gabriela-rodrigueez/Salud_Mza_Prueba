import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-control-stock',
  styleUrl: './control-stock.css',
  templateUrl: './control-stock.html',
})
export class ControlStock {}
