import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-configuracion',
  styleUrl: './configuracion.css',
  templateUrl: './configuracion.html',
})
export class Configuracion {}
