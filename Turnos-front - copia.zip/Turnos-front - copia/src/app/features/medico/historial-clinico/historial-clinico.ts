import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-historial-clinico',
  styleUrl: './historial-clinico.css',
  templateUrl: './historial-clinico.html',
})
export class HistorialClinico {}
