import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-agenda-medica',
  styleUrl: './agenda-medica.css',
  templateUrl: './agenda-medica.html',
})
export class AgendaMedica {}
