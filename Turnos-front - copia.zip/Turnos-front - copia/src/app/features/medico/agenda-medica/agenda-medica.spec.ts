import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgendaMedica } from './agenda-medica';

describe('AgendaMedica', () => {
  let component: AgendaMedica;
  let fixture: ComponentFixture<AgendaMedica>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgendaMedica],
    }).compileComponents();

    fixture = TestBed.createComponent(AgendaMedica);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
