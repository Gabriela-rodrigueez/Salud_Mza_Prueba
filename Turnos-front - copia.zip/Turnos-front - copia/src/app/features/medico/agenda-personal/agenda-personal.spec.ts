import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgendaPersonal } from './agenda-personal';

describe('AgendaPersonal', () => {
  let component: AgendaPersonal;
  let fixture: ComponentFixture<AgendaPersonal>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgendaPersonal],
    }).compileComponents();

    fixture = TestBed.createComponent(AgendaPersonal);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
