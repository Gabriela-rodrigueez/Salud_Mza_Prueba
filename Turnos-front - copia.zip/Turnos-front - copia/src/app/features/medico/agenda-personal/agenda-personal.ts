import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-agenda-personal',
  styleUrl: './agenda-personal.css',
  templateUrl: './agenda-personal.html',
})
export class AgendaPersonal {}
