---
name: Salud Mendoza System
colors:
  surface: '#fcf9f7'
  surface-dim: '#dcd9d8'
  surface-bright: '#fcf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f1'
  surface-container: '#f0edec'
  surface-container-high: '#eae8e6'
  surface-container-highest: '#e4e2e0'
  on-surface: '#1b1c1b'
  on-surface-variant: '#444748'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5d5e5f'
  primary: '#5d5e5e'
  on-primary: '#ffffff'
  primary-container: '#767777'
  on-primary-container: '#040505'
  inverse-primary: '#c6c6c6'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e2'
  on-secondary-container: '#646464'
  tertiary: '#605d5b'
  on-tertiary: '#ffffff'
  tertiary-container: '#797674'
  on-tertiary-container: '#ffffff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e6e2df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484644'
  background: '#fcf9f7'
  on-background: '#1b1c1b'
  surface-variant: '#e4e2e0'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-tabular:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  touch-target: 48px
---

## Brand & Style

This design system is built on the principles of **Institutional Trust, Efficiency, and Human Empathy**. As a public health management tool for the Province of Mendoza, it must bridge the gap between complex hospital bureaucracy and the diverse digital literacy of the citizenry. 

The design style is **Corporate / Modern** with a focus on high accessibility. It prioritizes clarity and functional speed over decorative flair. The aesthetic is clean and organized, utilizing a systematic grid to reduce cognitive load and "information noise" during stressful medical interactions.

- **Primary Goal:** Minimize friction in time-sensitive healthcare tasks (Check-in, Emergency, Medication withdrawal).
- **Tone:** Professional, calm, and dependable.
- **Visual Strategy:** Heavy use of white space to isolate critical data points, paired with high-contrast semantic signals to guide user attention.

## Colors

The palette is anchored by **Muted Gray-Blue (#767777)** and **Balanced Gray (#777777)**. These neutral and reliable tones are chosen for their clean, professional utility in public health environments. 

- **Primary Tone:** Used for navigation, primary actions, and institutional headers.
- **Secondary Tone:** Used for success states, healthcare-specific features (Pharmacy, Medical Records), and supporting interface elements.
- **Semantic Logic:** A strict traffic-light system is applied for statuses. 
    - **Urgent (#D32F2F):** Reserved for immediate attention and medical emergencies.
    - **Available (#2E7D32):** Used for stock confirmation and successful appointment booking.
    - **Low Stock (#ED6C02):** A cautionary signal for administrative replenishment.
- **Neutrals:** A range of understated grays are used for text and borders to ensure the interface remains easy on the eyes during prolonged use by administrative staff.

## Typography

**Inter** is selected for its exceptional legibility across digital screens and its neutral, professional tone. The typeface includes a tall x-height and open counters, which are critical for reading medical data and numeric values.

- **Hierarchy:** Headlines use a bold weight with slightly tighter letter-spacing to create a strong visual anchor for page sections.
- **Readability:** Body copy is set with generous line-height to ensure that older users or those with visual impairments can easily navigate clinical instructions.
- **Numerical Data:** For tables and pharmacy stock lists, use `data-tabular` settings to ensure numbers align vertically, aiding in rapid scanning of quantities and dates.
- **Mobile Scaling:** Large headlines are significantly reduced on mobile to ensure that critical content (like appointment times) remains "above the fold."

## Layout & Spacing

The system utilizes a **12-column fluid grid** for desktop and a **single-column fluid layout** for mobile devices. 

- **Responsive Strategy:** 
    - **Desktop (1280px+):** Sidebar navigation (280px fixed) with a fluid content area.
    - **Tablet (768px - 1024px):** 8-column grid with 24px margins. Sidebar collapses to an icon-only rail or drawer.
    - **Mobile (<768px):** 4-column grid with 16px margins.
- **Rhythm:** An 8pt spacing system is used for most components, while a 4pt "fine-tuning" unit is reserved for dense data tables and internal component padding.
- **Accessibility:** All interactive elements maintain a minimum **48px touch target** to accommodate mobile "Check-in Express" users and those with motor impairments.
- **Density:** Dashboard "Quick Links" should be spaced generously to prevent accidental clicks.

## Elevation & Depth

This system uses **Tonal Layers** supplemented by **Low-Contrast Outlines** to communicate hierarchy without introducing unnecessary visual clutter.

- **Surface Levels:** 
    - **Level 0 (Background):** Light neutral (#F9FAFB) background to define the application boundaries.
    - **Level 1 (Cards/Container):** Pure white (#FFFFFF) surfaces with a subtle 1px border (#E5E7EB).
    - **Level 2 (Modals/Popovers):** White surfaces with a soft, diffused shadow (10% opacity, 12px blur) to indicate temporary interaction layers.
- **Depth Metaphor:** Elements do not "float" high above the interface. Instead, they feel like organized paper records stacked neatly. 
- **Focus States:** High-contrast 2px outlines in Primary tone are required for keyboard navigation, ensuring the "digital gap" is bridged for users who do not use a mouse.

## Shapes

The shape language is **Soft (0.25rem)**. This provides a modern, clean look that feels approachable yet remains serious and structured.

- **Standard Components:** Buttons, input fields, and checkboxes use a `rounded` (4px) corner.
- **Large Containers:** Dashboard cards and modals use `rounded-lg` (8px) to soften the large surface areas.
- **Pill Elements:** Status badges (Available, Pending) and search tags use a fully rounded "pill" shape to distinguish them from interactive buttons.
- **Interactive Logic:** Cards should have a subtle hover state change (border-color shift) rather than a heavy shadow to maintain the clean, "paper-like" aesthetic.

## Components

### Buttons & Actions
- **Primary:** Solid Primary tone with high-contrast text. Reserved for the final step in a flow (e.g., "Confirm Appointment").
- **Secondary:** Outlined with Primary tone. Used for secondary actions (e.g., "Download PDF").
- **Tertiary/Ghost:** No border, Primary tone text. Used for "Cancel" or "Go Back."

### Status Badges
- **Format:** Pill-shaped, small uppercase labels.
- **Variants:**
    - **Urgent:** Red background, white text.
    - **Pending:** Light neutral background, Primary text.
    - **Available:** Green background, white text.

### Form Fields
- **Accessible Inputs:** Every input must have a visible `label-md` above the field. Help text should be provided for ID numbers or Medical Record entries.
- **Validation:** Clear red border and error text for invalid entries; green border only after a successful "Check-in" or "Validation" event.

### Dashboard Cards
- **Structure:** A bold headline, a clear primary metric or status, and a single "Direct Access" action at the bottom.
- **Urgent Cards:** These feature a 4px left-border accent in `status-urgent` Red to immediately draw the eye upon login.

### Scannable Assets
- **QR/Barcodes:** Displayed on a clear white card with high contrast. Include a "Brightness Toggle" or "Full Screen" button to ensure scanners at pharmacies can read the screen easily.

### File Uploads
- **Multimedia Area:** Dashed border container with specific icons for JPG, PNG, and PDF. Must show a progress bar during upload to satisfy RNF 5 (performance feedback).